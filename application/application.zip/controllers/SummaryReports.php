<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SummaryReports extends CI_Controller {

	
        function __construct() {
            parent::__construct();
            $this->load->model('SummaryReports_model');
        }

        public function index(){ 
              //I'm just using rand() function for data example 
            $this->view_search_report();
	}
        
        function view_search_report($datas=''){
            
            $column_array = array(
                                    'report_no' => 'Report No',
                                    'customer_name' => 'Customer Name',
                                    'gem_type_name' => 'Type',
                                    'spec_cost_name' => 'Special',
                                    'report_date' => 'Date',
                                    'object_val' => 'Item',
                                    'identification_val' => 'Identification',
                                    'variety_val' => 'Variety',
                                    'weight' => 'Weight',
                                    'dimension' => 'Dimension',
                                    'cut_val' => 'Cut',
                                    'polish' => 'Polish',
                                    'shape_val' => 'Shape',
                                    'color' => 'Color',
                                    'color_distribution_val' => 'Color Type',
                                    'transparency' => 'Transparency',
                                    'country_name' => 'Origin',
                                    'comments' => 'Comments',
                                    'special_note' => 'Special Note',
                                    'appendix' => 'Appendix',
                                    'added_on' => 'Added Date',
                                    'added_by' => 'Added By',
                                    );
            $selected_array = array(  'report_no' ,  'cutomer_name' ,  'gem_type_name' ,'report_date' , 'object_val', 'identification_val');
//                        echo '<pre>'; print_r($column_array); die;
            $data['report_cols'] = $column_array;
            $data['customer_list'] = get_dropdown_data(AGENTS,'agent_name','id','Customer Name');
            $data['report_cols_selected'] = $selected_array;
            $data['report_list'] = $this->SummaryReports_model->search_result();
            $data['main_content']='summary_reports/search_summary_report'; 
            $this->load->view('includes/template',$data);
	}
                    
	
         
        
        function load_data($id=''){ 
            if($id!=''){ 
                $data['property_data'] = $this->Report_model->get_single_row($id); 
             }else{
                 
                $data['report_no'] = gen_id(REPNO_PREFIX, LAB_REPORT, 'id');
             }
            $data['country_list'] = get_dropdown_data(COUNTRY_LIST,'country_name','country_code','Country');
            $data['agent_type_list'] = get_dropdown_data(AGENT_TYPE,'agent_type_name','id','Agent Type');
            $data['customer_list'] = get_dropdown_data(AGENTS,'agent_name','id','Customer Name');
            $data['gem_type_list'] = get_dropdown_data(GEM_CAT,'name','id','Stone Category');
            $data['spec_cost_list'] = get_dropdown_data(SPEC_COST,'name','id','Special Cost');
            
            $data['item_list_dpd']             = get_dropdown_data(DROPDOWN_LIST,'dropdown_value','id','Item',array('col'=>'dropdown_id', 'val'=>4));
            $data['identification_list_dpd']   = get_dropdown_data(DROPDOWN_LIST,'dropdown_value','id','Identification',array('col'=>'dropdown_id', 'val'=>5));
            $data['variety_list_dpd']          = get_dropdown_data(DROPDOWN_LIST,'dropdown_value','id','Variety',array('col'=>'dropdown_id', 'val'=>6));
            $data['cut_list_dpd']              = get_dropdown_data(DROPDOWN_LIST,'dropdown_value','id','Cut',array('col'=>'dropdown_id', 'val'=>7));
            $data['shape_list_dpd']            = get_dropdown_data(DROPDOWN_LIST,'dropdown_value','id','Shape',array('col'=>'dropdown_id', 'val'=>8));
            $data['color_type_list_dpd']       = get_dropdown_data(DROPDOWN_LIST,'dropdown_value','id','Color Distribution',array('col'=>'dropdown_id', 'val'=>9));
            $data['refractive_index_list_dpd'] = get_dropdown_data(DROPDOWN_LIST,'dropdown_value','id','Refractive Index',array('col'=>'dropdown_id', 'val'=>10));
            $data['specific_gravity_list_dpd'] = get_dropdown_data(DROPDOWN_LIST,'dropdown_value','id','Item',array('col'=>'dropdown_id', 'val'=>11));


            return $data;	
	}	
        
        function search_summary_report(){ 
                $status = $this->input->post('status'); 

		$search_data=array( 'report_no' => $this->input->post('report_no'), 
                                    'report_date' => $this->input->post('date'), 
                                    'date_monthly' => $this->input->post('date_monthly'), 
                                    'date_year' => $this->input->post('date_year'), 
                                    'customer' => $this->input->post('customer'), 
                                    'status' => ($status!='')?1:0);  

		$data_view['search_list'] = $this->SummaryReports_model->search_result($search_data);
                
                 $column_array = array(
                                    'report_no' => 'Report No',
                                    'customer_name' => 'Customer Name',
                                    'gem_type_name' => 'Type',
                                    'spec_cost_name' => 'Special',
                                    'report_date' => 'Date',
                                    'object_val' => 'Item',
                                    'identification_val' => 'Identification',
                                    'variety_val' => 'Variety',
                                    'weight' => 'Weight',
                                    'dimension' => 'Dimension',
                                    'cut_val' => 'Cut',
                                    'polish' => 'Polish',
                                    'shape_val' => 'Shape',
                                    'color' => 'Color',
                                    'color_distribution_val' => 'Color Type',
                                    'transparency' => 'Transparency',
                                    'country_name' => 'Origin',
                                    'comments' => 'Comments',
                                    'special_note' => 'Special Note',
                                    'appendix' => 'Appendix',
                                    'added_on' => 'Added Date',
                                    'added_by' => 'Added By',
                                    );
		$data_view['all_report_columns'] =  $column_array  ;
		$data_view['report_columns'] =  $this->input->post('report_columns')  ;

		$this->load->view('summary_reports/search_summary_report_result',$data_view);
	}
                                        
        function test(){
            $this->load->model('RemoteSync_model');
            $this->load->library('Curl');
            $this->RemoteSync_model->postToRemoteServer();
            //load library  
//            echo gen_id(REPNO_PREFIX, LAB_REPORT, 'id');
            echo '<img src ="'. base_url().COMPANY_LOGO.'logo_1.png">';

            echo COMPANY_LOGO.'logo_1.png';
        }
                                        
        function report_print($report_no){
            $report_data = $this->Report_model->get_single_row($report_no);
            $report_data = $report_data[0];
            redirect(base_url().LAB_REPORT_PDF.$report_data['report_no'].'.pdf');
        }
         
}
