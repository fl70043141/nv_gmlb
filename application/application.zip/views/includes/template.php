    <?php $this->load->view('includes/header'); ?>
<?php $this->load->view('includes/side_nav'); ?>
<?php $this->load->view($main_content); ?>
<?php $this->load->view('includes/footer'); ?>