#
# TABLE STRUCTURE FOR: additional_cost
#

DROP TABLE IF EXISTS `additional_cost`;

CREATE TABLE `additional_cost` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `cost` double NOT NULL,
  `deleted` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `additional_cost` (`id`, `name`, `cost`, `deleted`) VALUES ('1', 'Express', '1000', '0');
INSERT INTO `additional_cost` (`id`, `name`, `cost`, `deleted`) VALUES ('2', 'Semi Exp', '500', '0');
INSERT INTO `additional_cost` (`id`, `name`, `cost`, `deleted`) VALUES ('3', 'Normal', '0', '0');


#
# TABLE STRUCTURE FOR: agent_type
#

DROP TABLE IF EXISTS `agent_type`;

CREATE TABLE `agent_type` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `agent_type_name` varchar(50) NOT NULL,
  `agent_type_status` int(5) NOT NULL,
  `deleted` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `agent_type` (`id`, `agent_type_name`, `agent_type_status`, `deleted`) VALUES ('1', 'Platinum', '1', '0');
INSERT INTO `agent_type` (`id`, `agent_type_name`, `agent_type_status`, `deleted`) VALUES ('2', 'Gold', '1', '0');
INSERT INTO `agent_type` (`id`, `agent_type_name`, `agent_type_status`, `deleted`) VALUES ('3', 'Silver', '1', '0');


#
# TABLE STRUCTURE FOR: agents
#

DROP TABLE IF EXISTS `agents`;

CREATE TABLE `agents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_name` varchar(100) NOT NULL,
  `short_name` varchar(50) NOT NULL,
  `agent_type_id` int(5) NOT NULL,
  `description` varchar(300) NOT NULL,
  `reg_no` varchar(50) NOT NULL,
  `hotel_representative` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(50) NOT NULL,
  `postal_code` varchar(20) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(20) NOT NULL,
  `contact_person` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `fax` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `website` varchar(100) NOT NULL,
  `commision_plan` int(10) NOT NULL COMMENT '1-percentage,2-Fixed Amount',
  `commission_value` double NOT NULL,
  `credit_limit` double NOT NULL,
  `status` int(11) NOT NULL,
  `added_on` date NOT NULL,
  `added_by` int(11) NOT NULL,
  `updated_on` date NOT NULL,
  `updated_by` int(11) NOT NULL,
  `deleted` int(11) NOT NULL,
  `deleted_on` date NOT NULL,
  `deleted_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

INSERT INTO `agents` (`id`, `agent_name`, `short_name`, `agent_type_id`, `description`, `reg_no`, `hotel_representative`, `address`, `city`, `postal_code`, `state`, `country`, `contact_person`, `phone`, `fax`, `email`, `website`, `commision_plan`, `commission_value`, `credit_limit`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('6', 'Gem World', 'Gem World', '3', '', '', '', '123, Main Street, kollupitiya', 'Colombo', '', '', 'LK', '', '0771273711', '', '', '', '1', '0', '0', '0', '2017-05-20', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `agents` (`id`, `agent_name`, `short_name`, `agent_type_id`, `description`, `reg_no`, `hotel_representative`, `address`, `city`, `postal_code`, `state`, `country`, `contact_person`, `phone`, `fax`, `email`, `website`, `commision_plan`, `commission_value`, `credit_limit`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('2', 'ABC Gems', 'ABC Gems', '1', '', '', '', '123, Main Street, Dharga Town', 'Dharga Town', '', '', 'CA', '', '0771273711', '', '', '', '1', '0', '0', '1', '2017-04-15', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `agents` (`id`, `agent_name`, `short_name`, `agent_type_id`, `description`, `reg_no`, `hotel_representative`, `address`, `city`, `postal_code`, `state`, `country`, `contact_person`, `phone`, `fax`, `email`, `website`, `commision_plan`, `commission_value`, `credit_limit`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('3', 'Unique Sapphires', 'Unique Sapphires', '3', 'Neibhour', '', '', '123, Main Street, Dharga Town', 'Dharga Town', '', '', 'LK', '', '0771273711', '', '', '', '1', '0', '0', '1', '2017-05-11', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `agents` (`id`, `agent_name`, `short_name`, `agent_type_id`, `description`, `reg_no`, `hotel_representative`, `address`, `city`, `postal_code`, `state`, `country`, `contact_person`, `phone`, `fax`, `email`, `website`, `commision_plan`, `commission_value`, `credit_limit`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('4', 'Zone Ventures', 'Zone Ventures', '3', 'Neigbour', '', '', '123, Main Street, Dharga Town', 'Dharga Town', '', '', 'LK', '', '0771273711', '', '', '', '1', '0', '0', '1', '2017-05-11', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `agents` (`id`, `agent_name`, `short_name`, `agent_type_id`, `description`, `reg_no`, `hotel_representative`, `address`, `city`, `postal_code`, `state`, `country`, `contact_person`, `phone`, `fax`, `email`, `website`, `commision_plan`, `commission_value`, `credit_limit`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('5', 'Ventures Gems', 'Ventures Gems', '3', '', '', '', '123, Main Street, Dharga Town', 'Dharga Town', '', '', 'LK', '', '0771273711', '', '', '', '1', '0', '0', '0', '2017-05-18', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `agents` (`id`, `agent_name`, `short_name`, `agent_type_id`, `description`, `reg_no`, `hotel_representative`, `address`, `city`, `postal_code`, `state`, `country`, `contact_person`, `phone`, `fax`, `email`, `website`, `commision_plan`, `commission_value`, `credit_limit`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('7', 'Super Cut gem', 'Super Cut gem', '3', '', '', '', '123, Main Street, kollupitiya', 'Colombo', '', '', 'LK', '', '0771273711', '', '', '', '1', '0', '0', '1', '2017-05-21', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `agents` (`id`, `agent_name`, `short_name`, `agent_type_id`, `description`, `reg_no`, `hotel_representative`, `address`, `city`, `postal_code`, `state`, `country`, `contact_person`, `phone`, `fax`, `email`, `website`, `commision_plan`, `commission_value`, `credit_limit`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('8', 'Beauty Sapphires', 'Beauty Sapphires', '3', '', '', '', '123, Main Street, kollupitiya', 'Colombo', '', '', '', '', '0771273711', '', '', '', '1', '0', '0', '1', '2017-05-23', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `agents` (`id`, `agent_name`, `short_name`, `agent_type_id`, `description`, `reg_no`, `hotel_representative`, `address`, `city`, `postal_code`, `state`, `country`, `contact_person`, `phone`, `fax`, `email`, `website`, `commision_plan`, `commission_value`, `credit_limit`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('9', 'World collection ', 'World collection ', '3', '', '', '', '123, Main Street, kollupitiya', 'Colombo', '', '', '', '', '0771273711', '', '', '', '1', '0', '0', '1', '2017-05-23', '16', '2017-05-31', '16', '0', '0000-00-00', '0');
INSERT INTO `agents` (`id`, `agent_name`, `short_name`, `agent_type_id`, `description`, `reg_no`, `hotel_representative`, `address`, `city`, `postal_code`, `state`, `country`, `contact_person`, `phone`, `fax`, `email`, `website`, `commision_plan`, `commission_value`, `credit_limit`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('10', 'Color Stones', 'Color Stones', '3', 'Shocka', '', '', '123, Main Street, kollupitiya', 'Colombo', '', '', 'LK', '', '0771273711', '', '', '', '1', '0', '0', '0', '2017-05-25', '16', '2017-05-26', '16', '0', '0000-00-00', '0');
INSERT INTO `agents` (`id`, `agent_name`, `short_name`, `agent_type_id`, `description`, `reg_no`, `hotel_representative`, `address`, `city`, `postal_code`, `state`, `country`, `contact_person`, `phone`, `fax`, `email`, `website`, `commision_plan`, `commission_value`, `credit_limit`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('11', 'UK Exotica', 'UK Exotica', '3', '', '', '', '123, Main Street, Beruwela', 'Beruwela', '', '', 'LK', '', '0771273711', '', '', '', '1', '0', '0', '0', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `agents` (`id`, `agent_name`, `short_name`, `agent_type_id`, `description`, `reg_no`, `hotel_representative`, `address`, `city`, `postal_code`, `state`, `country`, `contact_person`, `phone`, `fax`, `email`, `website`, `commision_plan`, `commission_value`, `credit_limit`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('12', 'MINING GEMS', 'MINING GEMS', '3', 'N H Mawatha', '', '', '123, Main Street, Beruwela', 'Beruwela', '', '', 'LK', '', '0771273711', '', '', '', '1', '0', '0', '1', '2017-05-29', '16', '2017-05-29', '16', '0', '0000-00-00', '0');
INSERT INTO `agents` (`id`, `agent_name`, `short_name`, `agent_type_id`, `description`, `reg_no`, `hotel_representative`, `address`, `city`, `postal_code`, `state`, `country`, `contact_person`, `phone`, `fax`, `email`, `website`, `commision_plan`, `commission_value`, `credit_limit`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('13', 'Fahry Lafir', 'Fahry Lafir', '3', '', '', '', '123, Main Street, Beruwela', 'Beruwela', '', '', '', '', '0771273711', '', '', '', '1', '0', '0', '1', '2017-05-29', '17', '2017-05-31', '16', '0', '0000-00-00', '0');
INSERT INTO `agents` (`id`, `agent_name`, `short_name`, `agent_type_id`, `description`, `reg_no`, `hotel_representative`, `address`, `city`, `postal_code`, `state`, `country`, `contact_person`, `phone`, `fax`, `email`, `website`, `commision_plan`, `commission_value`, `credit_limit`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('14', 'London Gem Hous', 'London Gem Hous', '3', '', '', '', '123, Main Street, Beruwela', 'Beruwela', '', '', '', '', '0771273711', '', '', '', '1', '0', '0', '0', '2017-06-01', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `agents` (`id`, `agent_name`, `short_name`, `agent_type_id`, `description`, `reg_no`, `hotel_representative`, `address`, `city`, `postal_code`, `state`, `country`, `contact_person`, `phone`, `fax`, `email`, `website`, `commision_plan`, `commission_value`, `credit_limit`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('15', 'Fathhi Gems', 'Fathhi Gems', '3', 'Perara Rd', '', '', '123, Main Street, Beruwela', 'Beruwela', '', '', 'LK', '', '0771273711', '', '', '', '1', '0', '0', '1', '2017-06-03', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `agents` (`id`, `agent_name`, `short_name`, `agent_type_id`, `description`, `reg_no`, `hotel_representative`, `address`, `city`, `postal_code`, `state`, `country`, `contact_person`, `phone`, `fax`, `email`, `website`, `commision_plan`, `commission_value`, `credit_limit`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('16', 'XYZ Gems', 'XYZ Gems', '2', '', '', '', '123, Main Street, Beruwela', 'Beruwela', '', '', 'LK', '', '0771273711', '', '', '', '1', '0', '0', '1', '2017-06-05', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `agents` (`id`, `agent_name`, `short_name`, `agent_type_id`, `description`, `reg_no`, `hotel_representative`, `address`, `city`, `postal_code`, `state`, `country`, `contact_person`, `phone`, `fax`, `email`, `website`, `commision_plan`, `commission_value`, `credit_limit`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('17', 'First good', 'First good', '3', '', '', '', '123, Main Street, Beruwela', 'Beruwela', '', '', 'LK', '', '0771273711', '', '', '', '1', '0', '0', '1', '2017-06-05', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `agents` (`id`, `agent_name`, `short_name`, `agent_type_id`, `description`, `reg_no`, `hotel_representative`, `address`, `city`, `postal_code`, `state`, `country`, `contact_person`, `phone`, `fax`, `email`, `website`, `commision_plan`, `commission_value`, `credit_limit`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('18', 'Top gems', 'Top gems', '3', 'Ishrath Shuhaib - 0775729144\r\nUsman  - 0779725668', '', '', '123, Main Street, Beruwela', 'Beruwela', '', '', 'LK', '', '0771273711', '', '', '', '1', '0', '0', '1', '2017-06-06', '16', '0000-00-00', '0', '0', '0000-00-00', '0');


#
# TABLE STRUCTURE FOR: company
#

DROP TABLE IF EXISTS `company`;

CREATE TABLE `company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(100) NOT NULL,
  `street_address` varchar(100) NOT NULL,
  `address2` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(20) NOT NULL,
  `zipcode` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `fax` varchar(20) NOT NULL,
  `other_phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `website` varchar(100) NOT NULL,
  `company_type` varchar(50) NOT NULL,
  `company_grade` varchar(50) NOT NULL,
  `reg_no` varchar(50) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `added_on` date NOT NULL,
  `added_by` int(11) NOT NULL,
  `updated_on` date NOT NULL,
  `updated_by` int(11) NOT NULL,
  `deleted` int(11) NOT NULL,
  `deleted_on` date NOT NULL,
  `deleted_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `company` (`id`, `company_name`, `street_address`, `address2`, `city`, `state`, `country`, `zipcode`, `phone`, `fax`, `other_phone`, `email`, `website`, `company_type`, `company_grade`, `reg_no`, `logo`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('1', 'Nveloop Gem Laboratory', '51A Galle Road', '', 'Kaluthara South', 'Western Province', 'LK', 'KT-12070', '0094 77 544 0889', '', '', 'info@nveloop.com', 'www.nveloop.com.com', 'Gem Labarotary', '', 'REG001', 'logo_1.png', '1', '2016-04-27', '1', '2019-01-30', '0', '0', '0000-00-00', '0');


#
# TABLE STRUCTURE FOR: countries
#

DROP TABLE IF EXISTS `countries`;

CREATE TABLE `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(2) NOT NULL DEFAULT '',
  `country_name` varchar(100) NOT NULL DEFAULT '',
  `lat` varchar(50) NOT NULL,
  `lng` varchar(50) NOT NULL,
  `deleted` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `country_code` (`country_code`)
) ENGINE=MyISAM AUTO_INCREMENT=248 DEFAULT CHARSET=utf8;

INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('1', 'US', 'United States', '38', '-97', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('2', 'CA', 'Canada', '60', '-95', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('3', 'AF', 'Afghanistan', '33', '65', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('4', 'AL', 'Albania', '41', '20', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('5', 'DZ', 'Algeria', '28', '3', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('6', 'DS', 'American Samoa', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('7', 'AD', 'Andorra', '42.5', '1.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('8', 'AO', 'Angola', '-12.5', '18.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('9', 'AI', 'Anguilla', '18.25', '-63.16666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('10', 'AQ', 'Antarctica', '-90', '0', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('11', 'AG', 'Antigua and/or Barbuda', '17.05', '-61.8', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('12', 'AR', 'Argentina', '-34', '-64', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('13', 'AM', 'Armenia', '40', '45', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('14', 'AW', 'Aruba', '12.5', '-69.96666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('15', 'AU', 'Australia', '-27', '133', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('16', 'AT', 'Austria', '47.33333333', '13.33333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('17', 'AZ', 'Azerbaijan', '40.5', '47.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('18', 'BS', 'Bahamas', '24.25', '-76', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('19', 'BH', 'Bahrain', '26', '50.55', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('20', 'BD', 'Bangladesh', '24', '90', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('21', 'BB', 'Barbados', '13.16666666', '-59.53333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('22', 'BY', 'Belarus', '53', '28', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('23', 'BE', 'Belgium', '50.83333333', '4', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('24', 'BZ', 'Belize', '17.25', '-88.75', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('25', 'BJ', 'Benin', '9.5', '2.25', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('26', 'BM', 'Bermuda', '32.33333333', '-64.75', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('27', 'BT', 'Bhutan', '27.5', '90.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('28', 'BO', 'Bolivia', '-17', '-65', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('29', 'BA', 'Bosnia and Herzegovina', '44', '18', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('30', 'BW', 'Botswana', '-22', '24', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('31', 'BV', 'Bouvet Island', '-54.43333333', '3.4', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('32', 'BR', 'Brazil', '-10', '-55', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('33', 'IO', 'British Indian Ocean Territory', '-6', '71.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('34', 'BN', 'Brunei Darussalam', '4.5', '114.66666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('35', 'BG', 'Bulgaria', '43', '25', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('36', 'BF', 'Burkina Faso', '13', '-2', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('37', 'BI', 'Burundi', '-3.5', '30', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('38', 'KH', 'Cambodia', '13', '105', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('39', 'CM', 'Cameroon', '6', '12', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('40', 'CV', 'Cape Verde', '16', '-24', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('41', 'KY', 'Cayman Islands', '19.5', '-80.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('42', 'CF', 'Central African Republic', '7', '21', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('43', 'TD', 'Chad', '15', '19', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('44', 'CL', 'Chile', '-30', '-71', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('45', 'CN', 'China', '35', '105', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('46', 'CX', 'Christmas Island', '-10.5', '105.66666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('47', 'CC', 'Cocos (Keeling) Islands', '-12.5', '96.83333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('48', 'CO', 'Colombia', '4', '-72', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('49', 'KM', 'Comoros', '-12.16666666', '44.25', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('50', 'CG', 'Congo', '-1', '15', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('51', 'CK', 'Cook Islands', '-21.23333333', '-159.76666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('52', 'CR', 'Costa Rica', '10', '-84', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('53', 'HR', 'Croatia (Hrvatska)', '45.16666666', '15.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('54', 'CU', 'Cuba', '21.5', '-80', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('55', 'CY', 'Cyprus', '35', '33', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('56', 'CZ', 'Czech Republic', '49.75', '15.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('57', 'DK', 'Denmark', '56', '10', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('58', 'DJ', 'Djibouti', '11.5', '43', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('59', 'DM', 'Dominica', '15.41666666', '-61.33333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('60', 'DO', 'Dominican Republic', '19', '-70.66666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('61', 'TP', 'East Timor', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('62', 'EC', 'Ecuador', '-2', '-77.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('63', 'EG', 'Egypt', '27', '30', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('64', 'SV', 'El Salvador', '13.83333333', '-88.91666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('65', 'GQ', 'Equatorial Guinea', '2', '10', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('66', 'ER', 'Eritrea', '15', '39', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('67', 'EE', 'Estonia', '59', '26', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('68', 'ET', 'Ethiopia', '8', '38', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('69', 'FK', 'Falkland Islands (Malvinas)', '-51.75', '-59', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('70', 'FO', 'Faroe Islands', '62', '-7', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('71', 'FJ', 'Fiji', '-18', '175', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('72', 'FI', 'Finland', '64', '26', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('73', 'FR', 'France', '46', '2', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('74', 'FX', 'France, Metropolitan', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('75', 'GF', 'French Guiana', '4', '-53', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('76', 'PF', 'French Polynesia', '-15', '-140', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('77', 'TF', 'French Southern Territories', '-49.25', '69.167', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('78', 'GA', 'Gabon', '-1', '11.75', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('79', 'GM', 'Gambia', '13.46666666', '-16.56666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('80', 'GE', 'Georgia', '42', '43.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('81', 'DE', 'Germany', '51', '9', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('82', 'GH', 'Ghana', '8', '-2', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('83', 'GI', 'Gibraltar', '36.13333333', '-5.35', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('246', 'GK', 'Guernsey', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('84', 'GR', 'Greece', '39', '22', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('85', 'GL', 'Greenland', '72', '-40', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('86', 'GD', 'Grenada', '12.11666666', '-61.66666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('87', 'GP', 'Guadeloupe', '16.25', '-61.583333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('88', 'GU', 'Guam', '13.46666666', '144.78333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('89', 'GT', 'Guatemala', '15.5', '-90.25', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('90', 'GN', 'Guinea', '11', '-10', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('91', 'GW', 'Guinea-Bissau', '12', '-15', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('92', 'GY', 'Guyana', '5', '-59', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('93', 'HT', 'Haiti', '19', '-72.41666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('94', 'HM', 'Heard and Mc Donald Islands', '-53.1', '72.51666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('95', 'HN', 'Honduras', '15', '-86.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('96', 'HK', 'Hong Kong', '22.267', '114.188', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('97', 'HU', 'Hungary', '47', '20', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('98', 'IS', 'Iceland', '65', '-18', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('99', 'IN', 'India', '20', '77', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('244', 'IM', 'Isle of Man', '54.25', '-4.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('100', 'ID', 'Indonesia', '-5', '120', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('101', 'IR', 'Iran (Islamic Republic of)', '32', '53', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('102', 'IQ', 'Iraq', '33', '44', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('103', 'IE', 'Ireland', '53', '-8', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('104', 'IL', 'Israel', '31.47', '35.13', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('105', 'IT', 'Italy', '42.83333333', '12.83333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('106', 'CI', 'Ivory Coast', '8', '-5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('245', 'JE', 'Jersey', '49.25', '-2.16666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('107', 'JM', 'Jamaica', '18.25', '-77.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('108', 'JP', 'Japan', '36', '138', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('109', 'JO', 'Jordan', '31', '36', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('110', 'KZ', 'Kazakhstan', '48', '68', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('111', 'KE', 'Kenya', '1', '38', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('112', 'KI', 'Kiribati', '1.41666666', '173', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('113', 'KP', 'Korea, Democratic People\'s Republic of', '40', '127', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('114', 'KR', 'Korea, Republic of', '37', '127.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('115', 'XK', 'Kosovo', '42.666667', '21.166667', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('116', 'KW', 'Kuwait', '29.5', '45.75', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('117', 'KG', 'Kyrgyzstan', '41', '75', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('118', 'LA', 'Lao People\'s Democratic Republic', '18', '105', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('119', 'LV', 'Latvia', '57', '25', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('120', 'LB', 'Lebanon', '33.83333333', '35.83333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('121', 'LS', 'Lesotho', '-29.5', '28.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('122', 'LR', 'Liberia', '6.5', '-9.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('123', 'LY', 'Libyan Arab Jamahiriya', '25', '17', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('124', 'LI', 'Liechtenstein', '47.26666666', '9.53333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('125', 'LT', 'Lithuania', '56', '24', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('126', 'LU', 'Luxembourg', '49.75', '6.16666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('127', 'MO', 'Macau', '22.16666666', '113.55', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('128', 'MK', 'Macedonia', '41.83333333', '22', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('129', 'MG', 'Madagascar', '-20', '47', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('130', 'MW', 'Malawi', '-13.5', '34', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('131', 'MY', 'Malaysia', '2.5', '112.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('132', 'MV', 'Maldives', '3.25', '73', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('133', 'ML', 'Mali', '17', '-4', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('134', 'MT', 'Malta', '35.83333333', '14.58333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('135', 'MH', 'Marshall Islands', '9', '168', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('136', 'MQ', 'Martinique', '14.666667', '-61', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('137', 'MR', 'Mauritania', '20', '-12', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('138', 'MU', 'Mauritius', '-20.28333333', '57.55', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('139', 'TY', 'Mayotte', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('140', 'MX', 'Mexico', '23', '-102', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('141', 'FM', 'Micronesia, Federated States of', '6.91666666', '158.25', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('142', 'MD', 'Moldova, Republic of', '47', '29', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('143', 'MC', 'Monaco', '43.73333333', '7.4', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('144', 'MN', 'Mongolia', '46', '105', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('145', 'ME', 'Montenegro', '42.5', '19.3', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('146', 'MS', 'Montserrat', '16.75', '-62.2', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('147', 'MA', 'Morocco', '32', '-5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('148', 'MZ', 'Mozambique', '-18.25', '35', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('149', 'MM', 'Myanmar', '22', '98', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('150', 'NA', 'Namibia', '-22', '17', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('151', 'NR', 'Nauru', '-0.53333333', '166.91666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('152', 'NP', 'Nepal', '28', '84', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('153', 'NL', 'Netherlands', '52.5', '5.75', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('154', 'AN', 'Netherlands Antilles', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('155', 'NC', 'New Caledonia', '-21.5', '165.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('156', 'NZ', 'New Zealand', '-41', '174', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('157', 'NI', 'Nicaragua', '13', '-85', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('158', 'NE', 'Niger', '16', '8', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('159', 'NG', 'Nigeria', '10', '8', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('160', 'NU', 'Niue', '-19.03333333', '-169.86666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('161', 'NF', 'Norfolk Island', '-29.03333333', '167.95', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('162', 'MP', 'Northern Mariana Islands', '15.2', '145.75', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('163', 'NO', 'Norway', '62', '10', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('164', 'OM', 'Oman', '21', '57', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('165', 'PK', 'Pakistan', '30', '70', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('166', 'PW', 'Palau', '7.5', '134.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('243', 'PS', 'Palestine', '31.9', '35.2', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('167', 'PA', 'Panama', '9', '-80', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('168', 'PG', 'Papua New Guinea', '-6', '147', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('169', 'PY', 'Paraguay', '-23', '-58', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('170', 'PE', 'Peru', '-10', '-76', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('171', 'PH', 'Philippines', '13', '122', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('172', 'PN', 'Pitcairn', '-25.06666666', '-130.1', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('173', 'PL', 'Poland', '52', '20', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('174', 'PT', 'Portugal', '39.5', '-8', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('175', 'PR', 'Puerto Rico', '18.25', '-66.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('176', 'QA', 'Qatar', '25.5', '51.25', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('177', 'RE', 'Reunion', '-21.15', '55.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('178', 'RO', 'Romania', '46', '25', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('179', 'RU', 'Russian Federation', '60', '100', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('180', 'RW', 'Rwanda', '-2', '30', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('181', 'KN', 'Saint Kitts and Nevis', '17.33333333', '-62.75', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('182', 'LC', 'Saint Lucia', '13.88333333', '-60.96666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('183', 'VC', 'Saint Vincent and the Grenadines', '13.25', '-61.2', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('184', 'WS', 'Samoa', '-13.58333333', '-172.33333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('185', 'SM', 'San Marino', '43.76666666', '12.41666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('186', 'ST', 'Sao Tome and Principe', '1', '7', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('187', 'SA', 'Saudi Arabia', '25', '45', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('188', 'SN', 'Senegal', '14', '-14', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('189', 'RS', 'Serbia', '44', '21', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('190', 'SC', 'Seychelles', '-4.58333333', '55.66666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('191', 'SL', 'Sierra Leone', '8.5', '-11.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('192', 'SG', 'Singapore', '1.36666666', '103.8', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('193', 'SK', 'Slovakia', '48.66666666', '19.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('194', 'SI', 'Slovenia', '46.11666666', '14.81666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('195', 'SB', 'Solomon Islands', '-8', '159', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('196', 'SO', 'Somalia', '10', '49', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('197', 'ZA', 'South Africa', '-29', '24', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('198', 'GS', 'South Georgia South Sandwich Islands', '-54.5', '-37', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('199', 'ES', 'Spain', '40', '-4', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('200', 'LK', 'Sri Lanka', '7', '81', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('201', 'SH', 'St. Helena', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('202', 'PM', 'St. Pierre and Miquelon', '46.83333333', '-56.33333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('203', 'SD', 'Sudan', '15', '30', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('204', 'SR', 'Suriname', '4', '-56', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('205', 'SJ', 'Svalbard and Jan Mayen Islands', '78', '20', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('206', 'SZ', 'Swaziland', '-26.5', '31.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('207', 'SE', 'Sweden', '62', '15', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('208', 'CH', 'Switzerland', '47', '8', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('209', 'SY', 'Syrian Arab Republic', '35', '38', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('210', 'TW', 'Taiwan', '23.5', '121', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('211', 'TJ', 'Tajikistan', '39', '71', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('212', 'TZ', 'Tanzania, United Republic of', '-6', '35', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('213', 'TH', 'Thailand', '15', '100', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('214', 'TG', 'Togo', '8', '1.16666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('215', 'TK', 'Tokelau', '-9', '-172', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('216', 'TO', 'Tonga', '-20', '-175', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('217', 'TT', 'Trinidad and Tobago', '11', '-61', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('218', 'TN', 'Tunisia', '34', '9', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('219', 'TR', 'Turkey', '39', '35', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('220', 'TM', 'Turkmenistan', '40', '60', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('221', 'TC', 'Turks and Caicos Islands', '21.75', '-71.58333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('222', 'TV', 'Tuvalu', '-8', '178', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('223', 'UG', 'Uganda', '1', '32', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('224', 'UA', 'Ukraine', '49', '32', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('225', 'AE', 'United Arab Emirates', '24', '54', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('226', 'GB', 'United Kingdom', '54', '-2', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('227', 'UM', 'United States minor outlying islands', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('228', 'UY', 'Uruguay', '-33', '-56', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('229', 'UZ', 'Uzbekistan', '41', '64', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('230', 'VU', 'Vanuatu', '-16', '167', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('231', 'VA', 'Vatican City State', '41.9', '12.45', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('232', 'VE', 'Venezuela', '8', '-66', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('233', 'VN', 'Vietnam', '16.16666666', '107.83333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('234', 'VG', 'Virgin Islands (British)', '18.431383', '-64.62305', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('235', 'VI', 'Virgin Islands (U.S.)', '18.35', '-64.933333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('236', 'WF', 'Wallis and Futuna Islands', '-13.3', '-176.2', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('237', 'EH', 'Western Sahara', '24.5', '-13', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('238', 'YE', 'Yemen', '15', '48', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('239', 'YU', 'Yugoslavia', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('240', 'ZR', 'Zaire', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('241', 'ZM', 'Zambia', '-15', '30', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('242', 'ZW', 'Zimbabwe', '-20', '30', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('247', '--', 'Not Specified', '0', '-0', '0');


#
# TABLE STRUCTURE FOR: customer_base_discount
#

DROP TABLE IF EXISTS `customer_base_discount`;

CREATE TABLE `customer_base_discount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_type_id` int(11) NOT NULL,
  `gem_category_id` int(11) NOT NULL,
  `discount_type` int(5) NOT NULL COMMENT '1-percentage,2-Fixed Amount',
  `amount` double NOT NULL,
  `status` int(5) NOT NULL,
  `deleted` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `customer_base_discount` (`id`, `agent_type_id`, `gem_category_id`, `discount_type`, `amount`, `status`, `deleted`) VALUES ('1', '1', '1', '1', '20', '1', '0');
INSERT INTO `customer_base_discount` (`id`, `agent_type_id`, `gem_category_id`, `discount_type`, `amount`, `status`, `deleted`) VALUES ('2', '1', '2', '1', '15', '1', '0');
INSERT INTO `customer_base_discount` (`id`, `agent_type_id`, `gem_category_id`, `discount_type`, `amount`, `status`, `deleted`) VALUES ('3', '1', '3', '1', '20', '1', '0');
INSERT INTO `customer_base_discount` (`id`, `agent_type_id`, `gem_category_id`, `discount_type`, `amount`, `status`, `deleted`) VALUES ('4', '1', '4', '1', '15', '1', '0');
INSERT INTO `customer_base_discount` (`id`, `agent_type_id`, `gem_category_id`, `discount_type`, `amount`, `status`, `deleted`) VALUES ('5', '2', '1', '1', '10', '1', '0');
INSERT INTO `customer_base_discount` (`id`, `agent_type_id`, `gem_category_id`, `discount_type`, `amount`, `status`, `deleted`) VALUES ('6', '2', '2', '1', '10', '1', '0');
INSERT INTO `customer_base_discount` (`id`, `agent_type_id`, `gem_category_id`, `discount_type`, `amount`, `status`, `deleted`) VALUES ('7', '2', '3', '1', '10', '1', '0');
INSERT INTO `customer_base_discount` (`id`, `agent_type_id`, `gem_category_id`, `discount_type`, `amount`, `status`, `deleted`) VALUES ('8', '2', '4', '1', '10', '1', '0');
INSERT INTO `customer_base_discount` (`id`, `agent_type_id`, `gem_category_id`, `discount_type`, `amount`, `status`, `deleted`) VALUES ('9', '3', '1', '1', '5', '1', '0');
INSERT INTO `customer_base_discount` (`id`, `agent_type_id`, `gem_category_id`, `discount_type`, `amount`, `status`, `deleted`) VALUES ('10', '3', '2', '1', '4', '1', '0');
INSERT INTO `customer_base_discount` (`id`, `agent_type_id`, `gem_category_id`, `discount_type`, `amount`, `status`, `deleted`) VALUES ('11', '3', '3', '1', '5', '1', '0');
INSERT INTO `customer_base_discount` (`id`, `agent_type_id`, `gem_category_id`, `discount_type`, `amount`, `status`, `deleted`) VALUES ('12', '3', '4', '1', '4', '1', '0');


#
# TABLE STRUCTURE FOR: dropdown_list
#

DROP TABLE IF EXISTS `dropdown_list`;

CREATE TABLE `dropdown_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dropdown_id` int(100) NOT NULL,
  `dropdown_value` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `ri_value` varchar(100) NOT NULL DEFAULT '',
  `sg_value` varchar(100) NOT NULL DEFAULT '',
  `added_on` date NOT NULL,
  `added_by` int(11) NOT NULL,
  `updated_on` date NOT NULL,
  `updated_by` int(11) NOT NULL,
  `deleted` int(11) NOT NULL,
  `deleted_on` date NOT NULL,
  `deleted_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=219 DEFAULT CHARSET=latin1;

INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('8', '6', 'One Faceted Stone', '0', NULL, '', '', '2017-03-01', '1', '2017-03-17', '1', '1', '2017-03-17', '1');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('9', '6', 'Natural Blue Sapphire', '1', '41', '', '', '2017-03-01', '1', '2017-05-22', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('10', '7', 'Brilliant Cut', '1', NULL, '', '', '2017-03-01', '1', '2017-03-17', '1', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('11', '7', 'Very Good', '1', NULL, '', '', '2017-03-01', '1', '0000-00-00', '0', '1', '2017-05-11', '16');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('12', '7', 'Not bad', '1', NULL, '', '', '2017-03-01', '1', '2017-03-17', '1', '1', '2017-05-11', '16');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('13', '9', 'Royal Blue', '1', '0', '', '', '2017-03-01', '1', '2017-05-11', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('14', '7', 'Cushion Cut', '1', NULL, '', '', '2017-03-17', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('15', '4', 'Rough Stone', '1', NULL, '', '', '2017-03-17', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('16', '4', 'Natural', '1', NULL, '', '', '2017-03-17', '1', '0000-00-00', '0', '1', '2017-05-11', '16');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('17', '6', 'Natural Ruby', '1', '41', '', '', '2017-03-17', '1', '2017-05-22', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('18', '6', 'Natural Emerald', '1', '32', '1.56 - 1.60', '2.65 - 2.80', '2017-03-17', '1', '2017-05-27', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('19', '8', 'Cushion', '1', NULL, '', '', '2017-03-17', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('20', '8', 'Oval', '1', NULL, '', '', '2017-03-17', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('21', '8', 'Round', '1', NULL, '', '', '2017-03-17', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('22', '9', 'Cornflower', '1', '0', '', '', '2017-03-17', '1', '2017-05-11', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('23', '10', '1.772 - 2.770 (DR - 0/008)', '1', NULL, '', '', '2017-03-17', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('24', '10', '2.770 - 3.772  (DR - 1/008)', '1', NULL, '', '', '2017-03-17', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('25', '11', '4.0(+/- 0.1)', '1', NULL, '', '', '2017-03-17', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('26', '11', '4.5(+/- 0.2)', '1', NULL, '', '', '2017-03-17', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('27', '6', 'One Faceted Stones', '1', '0', '', '', '2017-03-17', '1', '2017-04-16', '1', '1', '2017-05-11', '16');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('28', '7', 'Emerald Cut', '1', NULL, '', '', '2017-03-18', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('29', '5', 'Natural Andalusite', '1', '0', '', '', '2017-03-18', '1', '2017-05-27', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('30', '9', 'Pigeon Blood', '1', '0', '', '', '2017-03-29', '1', '2017-05-11', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('31', '5', 'cabochon', '1', NULL, '', '', '2017-04-16', '1', '0000-00-00', '0', '1', '2017-05-11', '16');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('32', '5', 'Natural Beryl', '1', '18', '1.560 - 1.605', '2.63 - 2.91', '2017-04-16', '1', '2017-05-27', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('33', '6', 'Tourmaline', '1', '9', '7.5 - 8.0', '2.63 - 2.91', '2017-04-16', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('34', '6', 'Heliodor	', '1', '32', '', '', '2017-04-16', '1', '2017-05-27', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('35', '6', 'Jargoon', '1', '9', '7.5', '4.60 - 4.70', '2017-04-16', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('36', '5', 'Natural Grossular Garnet', '1', '0', '', '', '2017-04-16', '1', '2017-05-20', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('37', '6', 'Uvarovite', '1', '36', '6.5 - 7.5', '3.50 - 4.3', '2017-04-16', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('38', '5', 'Natural Opal', '1', '0', '', '', '2017-04-16', '1', '2017-05-27', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('39', '6', 'Water Opal', '1', '38', '5.5 - 6.5', '1.98 - 2.25', '2017-04-16', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('40', '6', 'White Opal', '1', '38', '5.5 - 6.5', '1.98 - 2.25', '2017-04-16', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('41', '5', 'Natural Corundum', '1', '0', '', '', '2017-04-16', '1', '2017-05-22', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('42', '6', 'Ruby', '1', '41', '3.91 - 4.01', '9.1', '2017-04-16', '1', '2017-04-18', '1', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('43', '6', 'Sapphire', '1', '41', '3.96 - 4.05', '9.0', '2017-04-16', '1', '2017-04-18', '1', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('44', '5', 'Natural Chrysoberyl', '1', '0', '', '', '2017-04-17', '1', '2017-05-23', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('45', '6', 'Cat\'s Eye', '1', '44', '1.746 - 1.755', '	3.68 - 3.78', '2017-04-17', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('46', '6', 'Natural Alexandrite', '1', '44', '', '', '2017-04-17', '1', '2017-05-27', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('47', '4', 'One loose faceted gemstone', '1', '0', '', '', '2017-05-11', '16', '2017-05-29', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('48', '4', 'One Rough Gemstone', '1', '0', '', '', '2017-05-11', '16', '2017-05-11', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('49', '6', 'Hambergite', '1', '0', '1.553 - 1.628, page 196', '2.35', '2017-05-11', '16', '2017-05-11', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('50', '6', 'Phenakite', '1', '0', '1.650 - 1.670, page 196', '2.95 - 2.97', '2017-05-11', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('51', '6', 'Danburite', '1', '0', '1.630 - 1.636, page 198', '2.97 - 3.03', '2017-05-11', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('52', '6', 'Axinite', '1', '0', '1.656 - 1.704, page 198', '3.26 - 3.36', '2017-05-11', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('53', '6', 'Benitotite', '1', '0', '1.757 - 1.804, page 200', '3.64 - 3.68', '2017-05-11', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('54', '6', 'Kornerupine', '1', '0', '1.660 - 1.699, page 202', '3.27 - 3.45', '2017-05-11', '16', '2017-05-11', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('55', '6', 'Beryllonite', '1', '0', '1.552 - 1.561, page 206', '2.80 - 2.87', '2017-05-11', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('56', '6', 'Brazilianite', '1', '0', '1.602 - 1.623, page 206', '2.98 - 2.99', '2017-05-11', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('57', '6', 'Amblygonite', '1', '0', '1.578 - 1.646,page 207', '3.01 - 3.11', '2017-05-11', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('58', '6', 'Enstatite', '1', '169', '1.650 - 1.680, page 208', '3.20 - 3.30', '2017-05-11', '16', '2017-05-28', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('59', '6', 'lazulite', '1', '0', '1.612 - 1.646, page 208', '3.04 - 3.14', '2017-05-11', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('60', '6', 'Tsavorite', '1', '36', '', '', '2017-05-18', '16', '2017-05-23', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('61', '7', 'Brilliant Mixed', '1', '0', '', '', '2017-05-18', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('62', '5', 'Natural Pyrope-Spessartine Garnet', '1', '0', '', '', '2017-05-20', '16', '2017-06-03', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('63', '6', 'Colour Change Garnet', '1', '62', '1.765', '4.1 - 4.2', '2017-05-20', '16', '2017-05-28', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('64', '0', 'Princess Cut', '1', '0', '', '', '2017-05-20', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('65', '8', 'Octagonal', '1', '0', '', '', '2017-05-20', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('66', '7', 'Scissor', '1', '0', '', '', '2017-05-20', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('67', '7', 'Princess', '1', '0', '', '', '2017-05-20', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('68', '0', 'Scissor (C) / Princess (P)', '1', '0', '', '', '2017-05-20', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('69', '7', 'Scissor / Princess', '1', '0', '', '', '2017-05-20', '16', '2017-05-20', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('70', '7', '----', '1', '0', '', '', '2017-05-21', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('71', '8', '----', '1', '0', '', '', '2017-05-21', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('72', '7', 'Mixed Cut', '1', '0', '', '', '2017-05-22', '16', '2017-05-22', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('73', '8', 'Rectangular', '1', '0', '', '', '2017-05-22', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('74', '6', 'Natural Pink Sapphire', '1', '41', '', '', '2017-05-22', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('75', '8', 'Pear', '1', '0', '', '', '2017-05-22', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('76', '8', 'Heart', '1', '0', '', '', '2017-05-22', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('77', '6', 'Natural Padparadscha', '1', '41', '', '', '2017-05-23', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('78', '6', 'Padparadscha', '1', '41', '', '', '2017-05-23', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('79', '5', 'Natural Pyrope-Almandine', '1', '0', '', '', '2017-05-24', '16', '2017-05-24', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('80', '6', 'Almandine', '1', '79', '', '', '2017-05-24', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('81', '6', 'Rhodolite', '1', '79', '', '', '2017-05-24', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('82', '5', 'Natural Tourmaline', '1', '0', '', '', '2017-05-24', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('83', '6', 'Rubelltte', '1', '82', '', '', '2017-05-24', '16', '2017-05-28', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('84', '6', 'Paraiba Tourmaline', '1', '156', '', '', '2017-05-24', '16', '2017-05-28', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('85', '6', 'Pyrope', '1', '79', '', '', '2017-05-24', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('86', '6', 'Natural Star Sapphire', '1', '41', '', '', '2017-05-25', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('87', '7', 'Cabochon', '1', '0', '', '', '2017-05-25', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('88', '0', 'A loose cabochon stone', '1', '0', '', '', '2017-05-25', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('89', '4', 'One loose cabochon stone', '1', '0', '', '', '2017-05-25', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('90', '6', 'Fancy Sapphire', '1', '41', '', '', '2017-05-25', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('91', '6', 'Natural Colour Changing Star Sapphire ', '1', '41', '', '', '2017-05-26', '16', '2017-05-28', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('92', '6', 'Blue Sapphire', '1', '41', '', '', '2017-05-26', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('93', '6', 'Natural Colour Changing Sapphire', '1', '41', '', '', '2017-05-26', '16', '2017-05-28', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('94', '6', 'Colour Changing Sapphire', '1', '41', '', '', '2017-05-26', '16', '2017-05-28', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('95', '8', 'Square', '1', '0', '', '', '2017-05-26', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('96', '6', 'Natural Fancy Sapphire', '1', '41', '', '', '2017-05-26', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('97', '6', 'Natural Cat\'s Eye', '1', '44', '', '', '2017-05-26', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('98', '6', 'Natural Cat\'s-Eye Alexandrite', '1', '44', '', '', '2017-05-26', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('99', '8', 'Near-Round', '1', '0', '', '', '2017-05-26', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('100', '5', 'Natural Amber', '1', '0', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('101', '5', 'Natural Apatite', '1', '0', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('102', '6', 'Apatite Cat\'s-eye', '1', '101', '', '', '2017-05-27', '16', '2017-05-28', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('103', '6', 'Aquamarine', '1', '32', '1.56 - 1.60', '2.65 - 2.80', '2017-05-27', '16', '2017-05-27', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('104', '6', 'Morganite', '1', '32', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('105', '6', 'Goshenite', '1', '32', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('106', '6', 'Brown Beryl', '1', '32', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('107', '6', 'Red Beryl', '1', '32', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('108', '6', 'Maxie Beryl', '1', '32', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('109', '5', 'Synthetic Beryl', '1', '0', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('110', '6', 'Synthetic Emerald', '1', '109', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('111', '5', 'Natural Calcite', '1', '0', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('112', '6', 'Iceland Spar', '1', '111', '1.48 - 1.66 / b.f: 0.172 / -ve', '', '2017-05-27', '16', '2017-05-27', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('113', '6', 'Banded Calcite', '1', '111', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('114', '6', 'Onyx Marble', '1', '111', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('115', '6', 'Limestone', '1', '111', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('116', '6', 'Alexandrite', '1', '44', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('117', '6', 'Chrysoberyl', '1', '44', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('118', '6', 'Natural Cat\'s-Eye', '1', '44', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('119', '5', 'Synthetic Chrysoberyl', '1', '0', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('120', '6', 'Synthetic Alexandrite', '1', '119', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('121', '5', 'Natural Coral', '1', '0', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('122', '6', 'Precious Coral', '1', '121', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('123', '6', 'Soft Coral', '1', '121', '', '', '2017-05-27', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('124', '7', 'Antique Cushion', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('125', '7', 'Baguette', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('126', '7', 'Rose', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('127', '7', 'Marquise', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('128', '7', 'Trillion', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('129', '7', 'Double Cabochon', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('130', '6', 'Pink Sapphire', '1', '41', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('131', '6', 'Natural Yellow Sapphire', '1', '41', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('132', '6', 'Yellow Sapphire', '1', '41', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('133', '6', 'Natural Brown Sapphire', '1', '41', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('134', '6', 'Brown Sapphire', '1', '41', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('135', '6', 'Natural Orange Sapphire', '1', '41', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('136', '6', 'Orange Sapphire', '1', '41', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('137', '6', 'Natural Green Sapphire', '1', '41', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('138', '6', 'Green Sapphire', '1', '41', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('139', '5', 'Natural Spinel', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('140', '6', 'Spinel', '1', '139', '1.718', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('141', '6', 'Cobalt Spinel', '1', '139', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('142', '6', 'Gahnospinel', '1', '139', '1.725 - 1.753', '3.58 - 4.06', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('143', '6', 'Colour Change Spinel', '1', '139', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('144', '6', 'Colour Change Tourmaline', '1', '82', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('145', '6', 'Natural Lavender Sapphire', '1', '41', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('146', '6', 'Lavender Sapphire', '1', '41', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('147', '5', 'Synthetic Spinel', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('148', '6', 'Synthetic Spinel', '1', '147', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('149', '5', 'Synthetic Corundum', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('150', '6', 'Synthetic Sapphire', '1', '149', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('151', '6', 'Synthetic Colour Change Sapphire', '1', '149', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('152', '6', 'Beryl', '1', '32', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('153', '6', 'Indicolite', '1', '82', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('154', '6', 'Watermelon Tourmaline', '1', '82', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('155', '0', 'Natural Tourmaline \'Cuprian Elbaite\'', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('156', '5', 'Natural Tourmaline \'Cuprian Elbaite\'', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('157', '6', 'Tourmaline cat\'s-eye', '1', '82', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('158', '6', 'Star Spinel', '1', '139', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('159', '5', 'Natural Zircon', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('160', '6', 'Zircon', '1', '159', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('161', '5', 'Natural Zoisite', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('162', '6', 'Zoisite', '1', '161', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('163', '6', 'Tanzanite', '1', '161', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('164', '5', 'Natural Topaz', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('165', '6', 'Topaz', '1', '164', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('166', '6', 'Imperial Topaz', '1', '164', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('167', '6', 'Mystic Topaz', '1', '164', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('168', '5', 'Natural Spodumene', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('169', '5', 'Natural Enstatite', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('170', '6', 'Kunzite', '1', '168', '1.66 - 1.68 / 0.015 - 0.016 / +ve', '3.17 - 3.19', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('171', '6', 'Hiddenite', '1', '168', 'Coloured by Chromium', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('172', '6', 'Green Spodumene', '1', '168', 'Coloured by Iron', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('173', '6', 'Spodumene', '1', '168', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('174', '5', 'Natural Sphene (Titanite)', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('175', '6', 'Sphene', '1', '174', '1.88 - 2.05 / 0.105 - 0.135 / B +ve', '3.4 - 3.6', '2017-05-28', '16', '2017-05-28', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('176', '5', 'Natural Sinhalite', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('177', '6', 'Sinhalite', '1', '176', '1.67 - 1.71 / 0.038 / B -ve', '3.47 - 3.50', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('178', '5', 'Natural Scapolite', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('179', '6', 'Scapolite', '1', '178', '1.54 - 1.58 / 0.009 - 0.026 / U -ve', '2.50 - 2.74', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('180', '5', 'Natural Rhodochrosite', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('181', '6', 'Rhodochrosite', '1', '180', '1.59 - 1.82 / 0.220 / U -ve', '3.5 - 3.7', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('182', '5', 'Natural Quartz', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('183', '6', 'Quartz', '1', '182', '1.53 - 1.56 / 0.009 / U +ve', '2.60 - 2.65', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('184', '6', 'Amethyst', '1', '182', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('185', '6', 'Lemon Quartz', '1', '182', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('186', '6', 'Rose Quartz', '1', '182', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('187', '6', 'Smoky Quartz', '1', '182', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('188', '6', 'Prasiolite', '1', '182', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('189', '6', 'Ametrine', '1', '182', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('190', '6', 'Citrine', '1', '182', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('191', '6', 'Quartz Cat\'s-Eye', '1', '182', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('192', '5', 'Natural Pyrite', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('193', '6', 'Pyrite', '1', '192', '1.73 - 1.84', '5', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('194', '5', 'Natural Prehnite', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('195', '6', 'Prehnite', '1', '194', '1.61 - 1.64 / 0.022 - 0.033/ B +ve', '2.8 - 2.9', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('196', '5', 'Natural Pezzottaite', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('197', '6', 'Pezzottaite', '1', '196', '1.60 - 1.62 / 0.008 - 0.011 / U -ve', '3.0 - 3.1', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('198', '5', 'Natural Peridot', '1', '0', '', '', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('199', '6', 'Peridot', '1', '198', '1.65 - 1.69', '3.32 - 3.37', '2017-05-28', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('200', '4', 'A pair of loose cabochon stones', '1', '0', '', '', '2017-05-29', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('201', '4', 'A faceted stone mounted in a ring', '1', '0', '', '', '2017-05-29', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('202', '4', 'A pair of loose faceted stones', '1', '0', '', '', '2017-05-29', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('203', '4', 'One loose faceted stone', '1', '0', '', '', '2017-05-29', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('204', '6', 'Grossularite', '1', '36', '', '', '2017-05-31', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('205', '5', '----', '1', '0', '', '', '2017-05-31', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('206', '6', '----', '1', '205', '', '', '2017-05-31', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('207', '12', 'Indication of heat present', '1', '0', '', '', '2017-06-01', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('208', '12', 'No indication of heat present', '1', '0', '', '', '2017-06-01', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('209', '12', 'No indications of clarity enhancement', '1', '0', '', '', '2017-06-03', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('210', '12', 'Indications of clarity enhancement', '1', '0', '', '', '2017-06-03', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('211', '12', 'Colour authenticity has not been determined', '1', '0', '', '', '2017-06-03', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('212', '12', 'Further  analyses  are  necessary  to  determine  whether  or  not  lighter chemical element(s) from', '1', '0', '', '', '2017-06-03', '16', '2017-06-03', '16', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('213', '12', 'Further  analyses  are  necessary  to  determine colour authenticity', '1', '0', '', '', '2017-06-03', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('214', '12', 'Further analyses necessary to determine whether or not light elements is present', '1', '0', '', '', '2017-06-03', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('215', '6', 'Multi-Colour Sapphire', '1', '41', '', '', '2017-06-05', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('216', '5', 'Natural Diaspore', '1', '0', '', '', '2017-06-05', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('217', '6', 'Diaspore', '1', '216', '1.702 - 1.750 / 0.048', '3.40', '2017-06-05', '16', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `dropdown_list` (`id`, `dropdown_id`, `dropdown_value`, `status`, `parent_id`, `ri_value`, `sg_value`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('218', '6', 'Colour Change Diaspore', '1', '216', '', '', '2017-06-05', '16', '0000-00-00', '0', '0', '0000-00-00', '0');


#
# TABLE STRUCTURE FOR: dropdown_list_names
#

DROP TABLE IF EXISTS `dropdown_list_names`;

CREATE TABLE `dropdown_list_names` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dropdown_list_name` varchar(50) NOT NULL,
  `dropdown_list_status` int(5) NOT NULL,
  `deleted` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `dropdown_list_names` (`id`, `dropdown_list_name`, `dropdown_list_status`, `deleted`) VALUES ('4', 'Item', '1', '0');
INSERT INTO `dropdown_list_names` (`id`, `dropdown_list_name`, `dropdown_list_status`, `deleted`) VALUES ('5', 'Identification', '1', '0');
INSERT INTO `dropdown_list_names` (`id`, `dropdown_list_name`, `dropdown_list_status`, `deleted`) VALUES ('6', 'Variety', '1', '0');
INSERT INTO `dropdown_list_names` (`id`, `dropdown_list_name`, `dropdown_list_status`, `deleted`) VALUES ('7', 'Cut', '1', '0');
INSERT INTO `dropdown_list_names` (`id`, `dropdown_list_name`, `dropdown_list_status`, `deleted`) VALUES ('8', 'Shape', '1', '0');
INSERT INTO `dropdown_list_names` (`id`, `dropdown_list_name`, `dropdown_list_status`, `deleted`) VALUES ('9', 'Color Type', '1', '0');
INSERT INTO `dropdown_list_names` (`id`, `dropdown_list_name`, `dropdown_list_status`, `deleted`) VALUES ('10', 'Refractive index', '1', '0');
INSERT INTO `dropdown_list_names` (`id`, `dropdown_list_name`, `dropdown_list_status`, `deleted`) VALUES ('11', 'Specific Gravity', '1', '0');
INSERT INTO `dropdown_list_names` (`id`, `dropdown_list_name`, `dropdown_list_status`, `deleted`) VALUES ('12', 'Comments', '1', '0');


#
# TABLE STRUCTURE FOR: floors
#

DROP TABLE IF EXISTS `floors`;

CREATE TABLE `floors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_id` int(20) NOT NULL,
  `floor_name` varchar(50) NOT NULL,
  `short_name` varchar(50) NOT NULL,
  `descreption` varchar(200) NOT NULL,
  `sort` varchar(20) NOT NULL,
  `status` int(20) NOT NULL,
  `added_on` date NOT NULL,
  `added_by` int(20) NOT NULL,
  `updated_on` date NOT NULL,
  `updated_by` int(20) NOT NULL,
  `deleted` int(20) NOT NULL,
  `deleted_on` date NOT NULL,
  `deleted_by` int(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hotel_id` (`hotel_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `floors` (`id`, `hotel_id`, `floor_name`, `short_name`, `descreption`, `sort`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('1', '1', 'Ground Floor', 'GFL', 'Front Office, Restaurant', '', '1', '2016-04-27', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `floors` (`id`, `hotel_id`, `floor_name`, `short_name`, `descreption`, `sort`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('2', '2', 'Roof Top', 'RFTP', 'Restaurant', '', '1', '2016-04-28', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `floors` (`id`, `hotel_id`, `floor_name`, `short_name`, `descreption`, `sort`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('3', '1', 'Second Floor1', 'SCFL', 'Kings Rooms, Deluxe Room', '', '0', '2016-04-28', '1', '2016-04-28', '1', '1', '2016-04-28', '1');
INSERT INTO `floors` (`id`, `hotel_id`, `floor_name`, `short_name`, `descreption`, `sort`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('4', '2', 'Fourth Floor', '4FLR', 'test', '', '0', '2016-04-28', '1', '0000-00-00', '0', '0', '0000-00-00', '0');


#
# TABLE STRUCTURE FOR: gem_category
#

DROP TABLE IF EXISTS `gem_category`;

CREATE TABLE `gem_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `testing_cost` double NOT NULL,
  `status` int(5) NOT NULL,
  `deleted` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `gem_category` (`id`, `name`, `testing_cost`, `status`, `deleted`) VALUES ('1', 'Precious', '2500', '1', '0');
INSERT INTO `gem_category` (`id`, `name`, `testing_cost`, `status`, `deleted`) VALUES ('2', 'Semi Precious', '1800', '1', '0');
INSERT INTO `gem_category` (`id`, `name`, `testing_cost`, `status`, `deleted`) VALUES ('3', 'Normal', '500', '1', '0');
INSERT INTO `gem_category` (`id`, `name`, `testing_cost`, `status`, `deleted`) VALUES ('4', 'Rare', '2000', '1', '0');


#
# TABLE STRUCTURE FOR: lab_report
#

DROP TABLE IF EXISTS `lab_report`;

CREATE TABLE `lab_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_no` varchar(15) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `gem_type` int(11) NOT NULL,
  `spec_cost` int(11) NOT NULL,
  `report_date` date NOT NULL,
  `object` varchar(50) NOT NULL,
  `identification` varchar(50) NOT NULL,
  `variety` varchar(100) NOT NULL,
  `weight` varchar(50) NOT NULL,
  `dimension` varchar(50) NOT NULL,
  `cut` varchar(50) NOT NULL,
  `polish` varchar(100) NOT NULL,
  `shape` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `color_distribution` varchar(100) NOT NULL,
  `show_color_distribution` int(5) NOT NULL,
  `transparency` varchar(100) NOT NULL,
  `comments` varchar(500) NOT NULL,
  `appendix` varchar(200) NOT NULL,
  `origin` varchar(50) NOT NULL,
  `show_origin` int(5) NOT NULL,
  `refractive_index` varchar(100) NOT NULL,
  `specific_gravity` varchar(100) NOT NULL,
  `ri_text_value` varchar(100) DEFAULT NULL,
  `sg_text_value` varchar(100) DEFAULT NULL,
  `hardness` varchar(100) NOT NULL,
  `optical_character` varchar(100) NOT NULL,
  `plechroism` varchar(100) NOT NULL,
  `absorption_spectrum` varchar(100) NOT NULL,
  `fluorebcence` varchar(100) NOT NULL,
  `magnification` varchar(100) NOT NULL,
  `special_note` varchar(500) NOT NULL,
  `status` int(5) NOT NULL,
  `sync_required` int(5) NOT NULL,
  `pic1` varchar(500) NOT NULL,
  `pic2` varchar(100) NOT NULL,
  `pic3` varchar(100) NOT NULL,
  `pic4` varchar(100) NOT NULL,
  `added_on` date NOT NULL,
  `added_by` int(11) NOT NULL,
  `updated_on` date NOT NULL,
  `updated_by` int(11) NOT NULL,
  `deleted` int(11) NOT NULL,
  `deleted_on` date NOT NULL,
  `deleted_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `report_no` (`report_no`),
  KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=latin1;

INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('1', 'ZV2017-987001', '2', '1', '3', '2017-05-18', '47', '41', '17', '1.25 carat', '3 x 2 x 1.5 mm', '61', 'Faceted', '20', 'Red', '', '0', 'Transparent', 'No indications of clarity enhancement', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', '', '0', '1', 'default.jpg', '', '', '', '2017-05-18', '16', '2017-06-06', '16', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('2', 'ZV2017-987002', '6', '2', '3', '2017-05-18', '47', '62', '63', '1.38 carat', '6.69 x 5.43 x 3.79 (mm)', '69', '', '65', 'Colour Change from Greyish Green to Reddish Brown', '', '0', '', '-', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', '', '1', '1', 'default.jpg', '', '', '', '2017-05-18', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('3', 'ZV2017-987003', '15', '3', '3', '2017-05-21', '47', '41', '74', '0.63  carat', '6.02 x 4.26 x 2.85 (mm)', '72', '', '20', 'Pink', '', '0', '', 'No Indication of heat present', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', '', '1', '1', 'default.jpg', '', '', '', '2017-05-21', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('4', 'ZV2017-987004', '7', '3', '3', '2017-05-21', '47', '41', '42', '1.00 carat', '5.84 x 4.55 x 3.32 (mm)', '72', '', '19', 'Red', '', '0', '', 'Indication of heat present', '', 'LK', '0', '', '', '3.91 - 4.01', '9.1', '', '', '', '', '', '', 'Atol Structure, Disolved rultil plus snow ball', '1', '1', 'default.jpg', '', '', '', '2017-05-21', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('5', 'ZV2017-987005', '11', '3', '3', '2017-05-21', '47', '41', '17', '1.06 carat', '6.62 x 5.16 x 3.30 (mm)', '72', '', '20', 'Red', '', '0', '', 'No indication of heat present', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', 'W-LW-F,  Amptibole, broken down', '1', '1', 'default.jpg', '', '', '', '2017-05-21', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('6', 'ZV2017-987006', '2', '3', '3', '2017-05-21', '47', '41', '42', '0.70 carat', '5.60 x 5.21 x 2.80 (mm)', '72', '', '20', 'Red', '', '0', '', 'Indication of heat present', '', 'LK', '0', '', '', '3.91 - 4.01', '9.1', '', '', '', '', '', '', 'Sign of heat included fraction, Strong W-LW-F,\r\nNatural inclusion presents rutile ', '1', '1', 'default.jpg', '', '', '', '2017-05-21', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('7', 'ZV2017-987007', '7', '3', '3', '2017-05-21', '47', '41', '43', '0.64 carat', '5.37 x 4.94 x 2.49 (mm)', '72', '', '19', 'Blue', '', '0', '', 'Indication of heat present', '', 'LK', '0', '', '', '3.96 - 4.05', '9.0', '', '', '', '', '', '', 'Sign of heat, inclusive fraction', '1', '1', 'default.jpg', '', '', '', '2017-05-21', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('8', 'ZV2017-987008', '5', '3', '3', '2017-05-21', '47', '41', '43', '0.73 carat', '5.32 x 4.23 x 3.34 (mm)', '72', '', '76', 'Pikish', '', '0', '', 'No Indication of heat present', '', 'LK', '0', '', '', '3.96 - 4.05', '9.0', '', '', '', '', '', '', 'Ratile, Triangular, Cloud (Moderate LW-F)', '1', '1', 'default.jpg', '', '', '', '2017-05-21', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('9', 'ZV2017-987009', '6', '3', '3', '2017-05-21', '47', '41', '17', '0.66 carat', '5.93 x 4.68 x 2.85 (mm)', '72', '', '73', 'Yellowish Brown', '', '0', '', 'No Indication of heat present', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', 'Fracture, Unalted rutile, Moderate LW-F', '1', '1', 'default.jpg', '', '', '', '2017-05-21', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('10', 'ZV2017-9870010', '7', '3', '3', '2017-05-21', '47', '41', '141', '1.01 carat', '5.88 x 4.61 x 3.61 (mm)', '72', '', '19', 'Pinkish Red', '', '0', '', 'No Indication of heat present', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', 'Natural,W-LW-F,Feathers and Rutile', '1', '1', 'default.jpg', '', '', '', '2017-05-21', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('11', 'ZV2017-9870011', '13', '3', '3', '2017-05-21', '47', '41', '17', '0.53 carat', '5.32 x 3.52 x 3.21 (mm)', '72', '', '19', 'Pinkish Red', '', '0', '', 'No Indication of heat present', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', 'Natural, Rutile Cloud and W-LW-F', '1', '1', 'default.jpg', '', '', '', '2017-05-21', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('12', 'ZV2017-9870012', '12', '3', '3', '2017-05-21', '47', '41', '17', '1.05 carat', '6.39 x 5.30 x 4.17 (mm)', '72', '', '75', 'Red', '', '0', '', 'No Indication of heat present', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', 'Natural, unalted crystal, W-LW-f and Rutile', '1', '0', 'default.jpg', '', '', '', '2017-05-21', '16', '2017-05-22', '16', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('13', 'ZV2017-9870013', '3', '3', '3', '2017-05-21', '47', '41', '43', '0.71 carat', '5.37 x 4.25 x 3.08 (mm)', '72', '', '19', 'Red', '', '0', '', 'No Indication of heat present', '', 'LK', '0', '', '', '3.96 - 4.05', '9.0', '', '', '', '', '', '', 'Natural, Rutile, Black Crystal inclusion, W-LW-F', '1', '1', 'default.jpg', '', '', '', '2017-05-21', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('14', 'ZV2017-9870014', '7', '3', '3', '2017-05-21', '47', '41', '52', '0.93 carat', '5.62 x 5.36 x 3.71 (mm)', '72', '', '76', 'Violet Blue', '', '0', '', 'No Indication of heat present', '', 'LK', '0', '', '', '1.656 - 1.704, page 198', '3.26 - 3.36', '', '', '', '', '', '', 'Natural, M-LW-F, Silk &amp;amp;Rutile unalted, ZONING', '1', '1', 'default.jpg', '', '', '', '2017-05-21', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('15', 'ZV2017-9870015', '16', '3', '3', '2017-05-21', '47', '41', '18', '0.76 carat', '5.77 x 4.65 x 3.22 (mm)', '72', '', '19', 'Red', '', '0', '', 'No Indication of heat present', '', 'LK', '0', '', '', '1.56 - 1.60', '2.65 - 2.80', '', '', '', '', '', '', 'M-LW-F,Rutile, Fracture', '1', '1', 'default.jpg', '', '', '', '2017-05-21', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('16', 'ZV2017-9870016', '7', '3', '3', '2017-05-22', '47', '41', '132', '0.53 carat', '5.31 x 4.12 x 2.62', '72', '', '19', 'Yellow', '', '0', '', 'Indication of heat present', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', '', '1', '1', 'default.jpg', '', '', '', '2017-05-22', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('17', 'ZV2017-9870017', '8', '3', '3', '2017-05-22', '47', '41', '17', '0.57 carat', '5.41 x 4.36 x 2.96 (mm)', '72', '', '20', 'Red', '', '0', '', 'No indication of heat present', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', '', '1', '1', 'default.jpg', '', '', '', '2017-05-22', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('18', 'ZV2017-9870018', '6', '3', '3', '2017-05-22', '47', '41', '17', '0.73 carat', '5.42 x 5.22 x 3.06 (mm)', '72', '', '19', 'Reddish Pink', '', '0', '', 'No indication of heat present', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', '', '1', '1', 'default.jpg', '', '', '', '2017-05-22', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('19', 'ZV2017-9870019', '7', '3', '3', '2017-05-22', '47', '41', '43', '0.79 carat', '5.51 x 5.08 x 3.35 (mm)', '72', '', '20', 'Red', '', '0', '', 'No indication of heat present', '', 'LK', '0', '', '', '3.96 - 4.05', '9.0', '', '', '', '', '', '', '', '1', '1', 'default.jpg', '', '', '', '2017-05-22', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('20', 'ZV2017-9870020', '7', '3', '3', '2017-05-22', '47', '41', '42', '0.51 carat', '4.99 x 4.02 x 2.73 (mm)', '72', '', '19', 'Pinkish Red', '', '0', '', 'Indication of heat present', '', 'LK', '0', '', '', '3.91 - 4.01', '9.1', '', '', '', '', '', '', '', '1', '1', 'default.jpg', '', '', '', '2017-05-22', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('21', 'ZV2017-9870021', '2', '3', '3', '2017-05-22', '47', '41', '17', '0.76 carat', '5.63 x 5.18 x 2.95 (mm)', '72', '', '19', 'Pinkish Red', '', '0', '', 'No indication of heat present', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', '', '1', '1', 'default.jpg', '', '', '', '2017-05-22', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('22', 'ZV2017-9870022', '5', '3', '3', '2017-05-22', '47', '41', '17', '0.60 carat', '4.89 x 4.03 x 3.18 (mm)', '72', '', '19', 'Purplish Pink', '', '0', '', 'No indication of heat present', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', '', '1', '1', 'default.jpg', '', '', '', '2017-05-22', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('23', 'ZV2017-9870023', '8', '3', '3', '2017-05-23', '47', '41', '78', '1.69 carat', '6.71 x 5.81 x 5.03 (mm)', '72', '', '20', 'Pinkish Orange', '', '0', '', 'Indication of high heat treatment present, returned without memo card on 24.05.2017 at 10 am.', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', 'Atol structure, snow ball inclusions, heat disk.\r\n\r\nPossible Be Treatment but cannot varify, need LIBS or ICPMS test, returned uncertified.', '0', '1', 'default.jpg', '', '', '', '2017-05-23', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('24', 'ZV2017-9870024', '9', '3', '3', '2017-05-23', '47', '44', '63', '4.35 carat', '9.48 x 9.20 x 6.25 (mm)', '72', '', '21', 'Colour change from yellowish green to brownish yel', '', '0', '', 'Customer request verbal only, changed his mine', '', 'LK', '0', '', '', '1.765', '4.1 - 4.2', '', '', '', '', '', '', '', '0', '1', 'default.jpg', '', '', '', '2017-05-23', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('25', 'ZV2017-9870025', '9', '3', '3', '2017-05-23', '47', '36', '60', '1.72 carat', '8.32 x 7.26 x 3.90 (mm)', '72', '', '76', 'Yellowish Green', '', '0', '', '---', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', 'Needle like inclusions ', '1', '1', 'default.jpg', '', '', '', '2017-05-23', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('26', 'ZV2017-9870026', '5', '3', '3', '2017-05-24', '47', '79', '81', '4.58 carat', '10.93 x 9.32 x 5.37 (mm)', '72', '', '20', 'Red', '', '0', '', '', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', '', '1', '1', 'default.jpg', '', '', '', '2017-05-24', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('27', 'ZV2017-9870027', '4', '3', '3', '2017-05-24', '47', '79', '81', '5.21 carat', '10.36 x 9.98 x 7.00 (mm)', '72', '', '75', 'Purplish Red', '', '0', '', '', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', '', '1', '1', 'default.jpg', '', '', '', '2017-05-24', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('28', 'ZV2017-9870028', '7', '3', '3', '2017-05-24', '47', '82', '83', '5.91 carat', '12.60 x 10.50 x 6.95 (mm)', '72', '', '19', 'Yellowish Green', '', '0', '', '', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', '', '1', '1', 'default.jpg', '', '', '', '2017-05-24', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('29', 'ZV2017-9870029', '11', '3', '3', '2017-05-24', '47', '79', '81', '7.14 carart', '12.08 x 10.31 x 7.26 (mm)', '72', '', '20', 'Deep Red', '', '0', '', '', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', '', '1', '1', 'default.jpg', '', '', '', '2017-05-24', '16', '2017-08-16', '1', '0', '0000-00-00', '0');
INSERT INTO `lab_report` (`id`, `report_no`, `customer_id`, `gem_type`, `spec_cost`, `report_date`, `object`, `identification`, `variety`, `weight`, `dimension`, `cut`, `polish`, `shape`, `color`, `color_distribution`, `show_color_distribution`, `transparency`, `comments`, `appendix`, `origin`, `show_origin`, `refractive_index`, `specific_gravity`, `ri_text_value`, `sg_text_value`, `hardness`, `optical_character`, `plechroism`, `absorption_spectrum`, `fluorebcence`, `magnification`, `special_note`, `status`, `sync_required`, `pic1`, `pic2`, `pic3`, `pic4`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('65', 'BGL1901-0000030', '3', '3', '1', '2019-01-30', '48', '41', '17', '2.65', '3.1 x 1.2 x 3.4 mm', '67', '', '76', '', '13', '0', '', 'Indication of heat present', '', 'LK', '0', '', '', '', '', '', '', '', '', '', '', '', '1', '1', 'default.jpg', '', '', '', '2019-01-30', '1', '0000-00-00', '0', '0', '0000-00-00', '0');


#
# TABLE STRUCTURE FOR: lab_report_sync
#

DROP TABLE IF EXISTS `lab_report_sync`;

CREATE TABLE `lab_report_sync` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_id` int(20) NOT NULL,
  `remote_sync_status` int(5) NOT NULL,
  `remote_sync_time` int(20) NOT NULL,
  `local_sync_time` int(20) NOT NULL,
  `deleted` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=243 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: module_actions
#

DROP TABLE IF EXISTS `module_actions`;

CREATE TABLE `module_actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL,
  `status` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=83 DEFAULT CHARSET=latin1;

INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('1', '1', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('2', '2', 'add', 'add', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('3', '2', 'edit', 'edit', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('4', '2', 'delete', 'delete', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('5', '2', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('6', '4', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('7', '5', 'index', 'indes', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('50', '11', 'test', 'test', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('49', '16', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('48', '15', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('11', '9', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('13', '2', 'search_user', 'search_user', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('14', '3', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('15', '2', 'validate', 'validate', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('16', '2', 'view', 'view', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('17', '11', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('18', '11', 'Search Company', 'search_company', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('21', '11', 'validate', 'validate', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('20', '11', 'Add', 'add', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('22', '11', 'Delete', 'delete', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('23', '11', 'Edit', 'edit', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('64', '18', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('63', '1', 'test', 'test', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('62', '17', 'sync_local_remote', 'sync_local_remote', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('61', '17', 'test', 'test', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('60', '17', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('31', '11', 'View', 'view', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('32', '13', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('33', '13', 'Search Property', 'search_property', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('34', '13', 'validate', 'validate', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('35', '13', 'Add', 'add', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('36', '13', 'Delete', 'delete', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('37', '13', 'Edit', 'edit', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('38', '13', 'View', 'view', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('39', '9', 'Search Agent', 'search_agent', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('40', '9', 'validate', 'validate', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('41', '9', 'Add', 'add', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('42', '9', 'Delete', 'delete', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('43', '9', 'Edit', 'edit', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('44', '9', 'View', 'view', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('45', '14', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('46', '14', 'edit', 'edit', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('47', '14', 'validate', 'validate', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('51', '16', 'Search Report', 'search_report', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('52', '16', 'Add', 'add', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('53', '16', 'Delete', 'delete', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('54', '16', 'Edit', 'edit', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('55', '16', 'View', 'view', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('56', '16', 'Test', 'test', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('57', '16', 'Validate', 'validate', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('58', '16', 'Lab Report Printing', 'report_print', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('59', '16', 'Lab Report Generating', 'report_generate', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('65', '18', 'Search Summary', 'search_summary_report', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('66', '19', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('67', '19', 'Search DropDown', 'search_dropdown', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('68', '19', 'Add', 'add', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('69', '19', 'Edit', 'edit', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('70', '19', 'Delete', 'delete', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('71', '19', 'validate', 'validate', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('72', '19', 'View', 'view', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('73', '16', 'report_print_pvc', 'report_print_pvc', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('74', '16', 'RI SG Retriewe', 'get_ri_sg_for_variety', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('75', '18', 'Print Summary Report', 'generate_pdf', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('82', '20', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('81', '20', 'Test', 'test', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('80', '20', 'Send Backup', 'send_backup', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('79', '20', 'Folder Backup', 'backup_folder', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('78', '20', 'DB Backup', 'backup_db', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('77', '20', 'Backup', 'backup', '1');


#
# TABLE STRUCTURE FOR: module_user_role
#

DROP TABLE IF EXISTS `module_user_role`;

CREATE TABLE `module_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_role_id` int(10) NOT NULL,
  `module_action_id` int(10) NOT NULL,
  `display_order` int(10) NOT NULL,
  `status` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=289 DEFAULT CHARSET=latin1;

INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('1', '1', '1', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('2', '1', '2', '10', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('3', '1', '3', '20', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('4', '1', '4', '25', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('5', '1', '5', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('6', '1', '6', '30', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('8', '1', '7', '5', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('54', '1', '51', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('53', '1', '50', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('52', '1', '49', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('12', '1', '11', '50', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('51', '1', '48', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('14', '1', '13', '45', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('15', '1', '2', '11', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('16', '1', '3', '12', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('17', '1', '4', '14', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('18', '1', '14', '50', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('19', '1', '15', '0', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('20', '1', '16', '50', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('21', '1', '17', '10', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('22', '1', '18', '20', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('23', '1', '20', '10', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('24', '1', '21', '10', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('25', '1', '22', '15', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('26', '1', '23', '25', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('63', '1', '60', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('64', '1', '61', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('65', '1', '62', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('66', '1', '63', '6', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('67', '1', '64', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('68', '1', '65', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('69', '1', '66', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('34', '1', '31', '45', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('35', '1', '32', '10', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('36', '1', '33', '20', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('37', '1', '34', '30', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('38', '1', '35', '40', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('39', '1', '36', '50', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('40', '1', '37', '60', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('41', '1', '38', '70', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('42', '1', '39', '50', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('43', '1', '40', '51', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('44', '1', '41', '52', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('45', '1', '42', '53', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('46', '1', '43', '54', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('47', '1', '44', '55', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('48', '1', '45', '10', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('49', '1', '46', '10', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('50', '1', '47', '120', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('55', '1', '52', '2', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('56', '1', '53', '3', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('57', '1', '54', '4', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('58', '1', '55', '5', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('59', '1', '56', '5', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('60', '1', '57', '5', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('61', '1', '58', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('62', '1', '59', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('70', '1', '67', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('71', '1', '68', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('72', '1', '69', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('73', '1', '70', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('74', '1', '71', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('75', '1', '72', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('76', '1', '73', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('77', '2', '1', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('78', '2', '2', '10', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('79', '2', '3', '20', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('80', '2', '4', '25', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('81', '2', '5', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('82', '2', '6', '30', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('83', '2', '7', '5', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('84', '2', '51', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('85', '2', '50', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('86', '2', '49', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('87', '2', '11', '50', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('88', '2', '48', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('89', '2', '13', '45', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('90', '2', '2', '11', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('91', '2', '3', '12', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('92', '2', '4', '14', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('93', '2', '14', '50', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('94', '2', '15', '0', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('95', '2', '16', '50', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('96', '2', '17', '10', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('97', '2', '18', '20', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('98', '2', '20', '10', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('99', '2', '21', '10', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('100', '2', '22', '15', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('101', '2', '23', '25', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('102', '2', '60', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('103', '2', '61', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('104', '2', '62', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('105', '2', '63', '6', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('106', '2', '64', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('107', '2', '65', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('108', '2', '66', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('109', '2', '31', '45', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('110', '2', '32', '10', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('111', '2', '33', '20', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('112', '2', '34', '30', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('113', '2', '35', '40', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('114', '2', '36', '50', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('115', '2', '37', '60', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('116', '2', '38', '70', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('117', '2', '39', '50', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('118', '2', '40', '51', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('119', '2', '41', '52', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('120', '2', '42', '53', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('121', '2', '43', '54', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('122', '2', '44', '55', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('123', '2', '45', '10', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('124', '2', '46', '10', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('125', '2', '47', '120', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('126', '2', '52', '2', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('127', '2', '53', '3', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('128', '2', '54', '4', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('129', '2', '55', '5', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('130', '2', '56', '5', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('131', '2', '57', '5', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('132', '2', '58', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('133', '2', '59', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('134', '2', '67', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('135', '2', '68', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('136', '2', '69', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('137', '2', '70', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('138', '2', '71', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('139', '2', '72', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('140', '2', '73', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('141', '3', '1', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('142', '3', '2', '10', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('143', '3', '3', '20', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('144', '3', '4', '25', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('145', '3', '5', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('146', '3', '6', '30', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('147', '3', '7', '5', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('148', '3', '51', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('149', '3', '50', '1', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('150', '3', '49', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('151', '3', '11', '50', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('152', '3', '48', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('153', '3', '13', '45', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('154', '3', '2', '11', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('155', '3', '3', '12', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('156', '3', '4', '14', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('157', '3', '14', '50', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('158', '3', '15', '0', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('159', '3', '16', '50', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('160', '3', '17', '10', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('161', '3', '18', '20', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('162', '3', '20', '10', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('163', '3', '21', '10', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('164', '3', '22', '15', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('165', '3', '23', '25', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('166', '3', '60', '6', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('167', '3', '61', '6', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('168', '3', '62', '6', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('169', '3', '63', '6', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('170', '3', '64', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('171', '3', '65', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('172', '3', '66', '6', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('173', '3', '31', '45', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('174', '3', '32', '10', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('175', '3', '33', '20', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('176', '3', '34', '30', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('177', '3', '35', '40', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('178', '3', '36', '50', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('179', '3', '37', '60', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('180', '3', '38', '70', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('181', '3', '39', '50', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('182', '3', '40', '51', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('183', '3', '41', '52', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('184', '3', '42', '53', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('185', '3', '43', '54', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('186', '3', '44', '55', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('187', '3', '45', '10', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('188', '3', '46', '10', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('189', '3', '47', '120', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('190', '3', '52', '2', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('191', '3', '53', '3', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('192', '3', '54', '4', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('193', '3', '55', '5', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('194', '3', '56', '5', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('195', '3', '57', '5', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('196', '3', '58', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('197', '3', '59', '6', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('198', '3', '67', '6', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('199', '3', '68', '6', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('200', '3', '69', '6', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('201', '3', '70', '6', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('202', '3', '71', '6', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('203', '3', '72', '6', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('204', '3', '73', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('205', '4', '1', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('206', '4', '2', '10', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('207', '4', '3', '20', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('208', '4', '4', '25', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('209', '4', '5', '1', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('210', '4', '6', '30', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('211', '4', '7', '5', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('212', '4', '51', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('213', '4', '50', '1', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('214', '4', '49', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('215', '4', '11', '50', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('216', '4', '48', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('217', '4', '13', '45', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('218', '4', '2', '11', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('219', '4', '3', '12', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('220', '4', '4', '14', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('221', '4', '14', '50', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('222', '4', '15', '0', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('223', '4', '16', '50', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('224', '4', '17', '10', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('225', '4', '18', '20', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('226', '4', '20', '10', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('227', '4', '21', '10', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('228', '4', '22', '15', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('229', '4', '23', '25', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('230', '4', '60', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('231', '4', '61', '6', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('232', '4', '62', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('233', '4', '63', '6', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('234', '4', '64', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('235', '4', '65', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('236', '4', '66', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('237', '4', '31', '45', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('238', '4', '32', '10', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('239', '4', '33', '20', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('240', '4', '34', '30', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('241', '4', '35', '40', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('242', '4', '36', '50', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('243', '4', '37', '60', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('244', '4', '38', '70', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('245', '4', '39', '50', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('246', '4', '40', '51', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('247', '4', '41', '52', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('248', '4', '42', '53', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('249', '4', '43', '54', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('250', '4', '44', '55', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('251', '4', '45', '10', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('252', '4', '46', '10', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('253', '4', '47', '120', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('254', '4', '52', '2', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('255', '4', '53', '3', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('256', '4', '54', '4', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('257', '4', '55', '5', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('258', '4', '56', '5', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('259', '4', '57', '5', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('260', '4', '58', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('261', '4', '59', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('262', '4', '67', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('263', '4', '68', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('264', '4', '69', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('265', '4', '70', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('266', '4', '71', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('267', '4', '72', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('268', '4', '73', '6', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('269', '1', '74', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('270', '2', '74', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('271', '1', '75', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('272', '2', '75', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('273', '3', '75', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('274', '4', '75', '1', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('286', '2', '82', '15', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('278', '1', '82', '15', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('277', '1', '81', '15', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('285', '2', '81', '15', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('276', '1', '80', '15', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('284', '2', '80', '15', '0');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('275', '1', '79', '15', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('283', '2', '79', '15', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('287', '2', '78', '15', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('288', '1', '78', '15', '1');


#
# TABLE STRUCTURE FOR: modules
#

DROP TABLE IF EXISTS `modules`;

CREATE TABLE `modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(50) NOT NULL,
  `page_id` varchar(200) NOT NULL,
  `img_class` varchar(50) NOT NULL,
  `is_parent` int(5) NOT NULL,
  `show_below` int(5) NOT NULL,
  `hidden` int(5) NOT NULL,
  `user_permission_apply` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('1', 'Dashboard', 'dashboard', 'fa fa-dashboard', '1', '0', '0', '0');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('2', 'Users', 'users', 'fa fa-user', '0', '3', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('3', 'All Users', 'users', 'fa fa-user', '1', '0', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('4', 'Settings', '#', 'fa fa-gears', '1', '0', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('16', 'Report Creation', 'reports', 'fa fa-file-text', '0', '15', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('15', 'BGL Reports', 'gem_reports', 'fa fa-bar-chart', '1', '0', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('9', 'Customers', 'agents', 'fa fa-group', '0', '15', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('11', 'Company Details', 'company', 'fa fa-building-o', '0', '4', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('17', 'Report Sync', 'reportSync', 'fa fa-refresh', '0', '4', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('13', 'Other', 'property', 'fa fa-sitemap', '0', '4', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('14', 'User Permission', 'userPermission', 'fa fa-lock', '0', '3', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('18', 'Summary Reports', 'summaryReports', 'fa fa-bar-chart', '1', '0', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('19', 'Drop-down List', 'DropDownList', 'fa fa-list', '0', '4', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('20', 'Backup', 'backup', 'fa fa-hdd-o', '0', '4', '0', '1');


#
# TABLE STRUCTURE FOR: tarrif_type
#

DROP TABLE IF EXISTS `tarrif_type`;

CREATE TABLE `tarrif_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tarrif_type_name` varchar(100) NOT NULL,
  `short_name` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `base_adult` int(20) NOT NULL,
  `max_adult` int(20) NOT NULL,
  `base_child` int(20) NOT NULL,
  `max_child` int(20) NOT NULL,
  `over_booking_percentage` double NOT NULL,
  `status` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tarrif_type` (`id`, `tarrif_type_name`, `short_name`, `description`, `base_adult`, `max_adult`, `base_child`, `max_child`, `over_booking_percentage`, `status`) VALUES ('1', 'Deluxe Twin', 'DT', '', '1', '2', '1', '2', '40', '1');
INSERT INTO `tarrif_type` (`id`, `tarrif_type_name`, `short_name`, `description`, `base_adult`, `max_adult`, `base_child`, `max_child`, `over_booking_percentage`, `status`) VALUES ('2', 'Superior Triple', 'ST', '', '3', '1', '1', '1', '50', '1');


#
# TABLE STRUCTURE FOR: time_base
#

DROP TABLE IF EXISTS `time_base`;

CREATE TABLE `time_base` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time_base_name` varchar(100) NOT NULL,
  `short_name` varchar(50) NOT NULL,
  `hours` double NOT NULL,
  `descreption` varchar(200) NOT NULL,
  `status` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `time_base` (`id`, `time_base_name`, `short_name`, `hours`, `descreption`, `status`) VALUES ('1', 'Daily', 'DL', '24', 'Daily Tarriff calculation', '1');
INSERT INTO `time_base` (`id`, `time_base_name`, `short_name`, `hours`, `descreption`, `status`) VALUES ('2', 'Hourly', 'HR', '1', 'Hourly Tariff calculations', '1');
INSERT INTO `time_base` (`id`, `time_base_name`, `short_name`, `hours`, `descreption`, `status`) VALUES ('3', 'Weekly', 'WK', '168', 'Weekly (7 Days)', '1');


#
# TABLE STRUCTURE FOR: user_auth
#

DROP TABLE IF EXISTS `user_auth`;

CREATE TABLE `user_auth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_role_id` int(10) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `user_password` text NOT NULL,
  `tmp_pwd` text NOT NULL,
  `tmp_pwd_req_date` date NOT NULL,
  `active_from` date NOT NULL,
  `active_to` date NOT NULL,
  `status` int(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_role` (`user_role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO `user_auth` (`id`, `user_role_id`, `user_name`, `user_password`, `tmp_pwd`, `tmp_pwd_req_date`, `active_from`, `active_to`, `status`) VALUES ('1', '1', 'fahry', 'I98FzpnFLhO2dBhAj0P6pROEu2zqWAq5gcvnvG/aPJrO9m+wNu+ryS9cfBVjDFUVU5S889QriWxf0a+Gw5NkCA==', '', '0000-00-00', '0000-00-00', '0000-00-00', '1');
INSERT INTO `user_auth` (`id`, `user_role_id`, `user_name`, `user_password`, `tmp_pwd`, `tmp_pwd_req_date`, `active_from`, `active_to`, `status`) VALUES ('16', '2', 'faheem', '89McXZX26pzn1PLkX6XMZ06YwC24sNs+bNt/pGHz9Ggg5B28OY0YPa9+1fdZcp7cTbunIa/mrx2vJFLK1gv3RA==', '', '0000-00-00', '0000-00-00', '0000-00-00', '1');
INSERT INTO `user_auth` (`id`, `user_role_id`, `user_name`, `user_password`, `tmp_pwd`, `tmp_pwd_req_date`, `active_from`, `active_to`, `status`) VALUES ('17', '4', 'Riham', 'LnODVdefcnp7t1MK7tUiFuEGhYm7MOhHqR0OPAGLoFMLsfGYO36EiohDfOuxG9ysgF7ATP0MJo0Zx1jovuZhAw==', '', '0000-00-00', '0000-00-00', '0000-00-00', '1');


#
# TABLE STRUCTURE FOR: user_details
#

DROP TABLE IF EXISTS `user_details`;

CREATE TABLE `user_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `auth_id` int(10) NOT NULL,
  `first_name` varchar(75) NOT NULL,
  `last_name` varchar(75) NOT NULL,
  `company_id` int(10) NOT NULL DEFAULT '1',
  `address` varchar(150) NOT NULL,
  `email` varchar(75) NOT NULL,
  `tel` varchar(15) NOT NULL,
  `pic` text NOT NULL,
  `added_on` date NOT NULL,
  `added_by` int(5) NOT NULL,
  `updated_on` date NOT NULL,
  `updated_by` int(5) NOT NULL,
  `deleted` int(5) NOT NULL,
  `deleted_on` date NOT NULL,
  `deleted_by` int(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_auth` (`auth_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO `user_details` (`id`, `auth_id`, `first_name`, `last_name`, `company_id`, `address`, `email`, `tel`, `pic`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('1', '1', 'Fahry', 'Lafir', '1', '82, W. A. D. Ramanayake Mawatha, Colombo - 02', 'fahrydgt@gmail.com', '0775440889', '', '2016-01-13', '1', '2017-03-17', '1', '0', '0000-00-00', '0');
INSERT INTO `user_details` (`id`, `auth_id`, `first_name`, `last_name`, `company_id`, `address`, `email`, `tel`, `pic`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('15', '16', 'Faheem', 'Farook', '1', '', 'faheem@nveloop.com', '0112121212', '', '2016-04-25', '1', '2019-01-30', '0', '0', '0000-00-00', '0');
INSERT INTO `user_details` (`id`, `auth_id`, `first_name`, `last_name`, `company_id`, `address`, `email`, `tel`, `pic`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('16', '17', 'Riham', 'user1', '1', '', 'info@berberyngemlab.com', '', '', '2017-05-22', '1', '2017-05-28', '16', '0', '0000-00-00', '0');


#
# TABLE STRUCTURE FOR: user_role
#

DROP TABLE IF EXISTS `user_role`;

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_role` varchar(50) NOT NULL,
  `role_cat` varchar(50) NOT NULL,
  `deleted` int(5) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_cat` (`role_cat`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `user_role` (`id`, `user_role`, `role_cat`, `deleted`) VALUES ('1', 'Administrator', 'ADMIN', '0');
INSERT INTO `user_role` (`id`, `user_role`, `role_cat`, `deleted`) VALUES ('3', 'Manager', 'MANAGER', '0');
INSERT INTO `user_role` (`id`, `user_role`, `role_cat`, `deleted`) VALUES ('4', 'Gen Staff', 'STAFF', '0');
INSERT INTO `user_role` (`id`, `user_role`, `role_cat`, `deleted`) VALUES ('2', 'System Administrator', 'SYSTEM_ADMIN', '0');


